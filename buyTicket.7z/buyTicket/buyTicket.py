#python3.6.1#data：2018-01-03#author:LGC247CG
"""说明：1.该脚本主要是提供一个实现思路，实现方法有很多，可以优化的地方也有很多，触发机制也可以自己设置，代码以压缩到最短，只是为了让大家都可以看明白
2.正常网络状况下，不设置指定时间时，从点击确认验证码到下单基本上1秒左右，所以速度上还是没问题的
3.由于同时勾选多人和单人使用所需时间基本相同，希望该方法只用于技术交流，请勿作为黄牛使用
4.在作为技术交流的情况下，如果验证码可以实现将可以完全实现自动抢票：
--1>验证码有一定规律和数量，可以利用脚本获取所有图片，并加上相应标签
--2>将页面的文字和标签相匹配，再将图片进行相似度计算，对对应图片进行点击操作
--3>或是训练深度学习的图片识别模型，通过算法识别"""
from selenium import webdriver      #控制浏览器
from selenium.webdriver.common.keys import Keys  #用于给元素赋值
import time   #时间模块
from selenium.webdriver.support.select import Select  #控制下拉框模块
from selenium.webdriver.common.by import By   #寻找元素模块
from selenium.webdriver.support.ui import WebDriverWait  #“显示等待”模块
from selenium.webdriver.support import expected_conditions as EC  #等待条件模块

browser = webdriver.Firefox()
browser.get("https://kyfw.12306.cn/otn/login/init")
browser.find_element_by_id('username').clear()
browser.find_element_by_id('username').send_keys('603729324@qq.com')
browser.find_element_by_id('password').send_keys('Guofan19920930')
time.sleep(5)
try:
    browser.find_element_by_id('loginSub').click()
except:
    browser.find_element_by_class_name('touclick-bgimg touclick-reload touclick-reload-normal').click()
    time.sleep(15)
    browser.find_element_by_id('loginSub').click()#跳转到车票预定页面time.sleep(2)
#browser.switch_to_window(browser.window_handles[1]) #为获得当前页面的handle
time.sleep(10)
#sreach_window=browser.current_window_handle
#sreach_window =browser.current_window_handle#为获得当前页面的handle
clickReserve = browser.find_element_by_id('selectYuding').click()#出发地点和到达地点设置WebDriverWait(browser,10).until(EC.presence_of_element_located((By.ID, "fromStation")))
jsf = 'var a = document.getElementById("fromStation");a.value = "HGH"'
browser.execute_script(jsf)
jst = 'var a = document.getElementById("toStation");a.value = "TIJ"'
browser.execute_script(jst)
js = "document.getElementById('train_date').removeAttribute('readonly')"
browser.execute_script(js)
browser.find_element_by_id('train_date').clear()
browser.find_element_by_id('train_date').send_keys('2018-02-06')
search = browser.find_element_by_id('query_ticket').click()#对于时间，我一直觉得网站计算的时间和自己获取的时间差一秒左右，这个根据不同环境自己测试start_time = "Thu Jan 04 10:00:00 2018"    #首先设置需要抢票的时间b = time.mktime(time.strptime(start_time,"%a %b %d %H:%M:%S %Y"))
#print(time.strftime("%a %b %d %H:%M:%S %Y", time.localtime(b)) )  #此处是为了调试代码使用，可忽略，不影响使用a = float(b)-time.time()    #利用自己设置的时间减去当前时间的时间戳time.sleep(a)    #上一步骤得出的秒数就是需要等待抢票的时间browser.find_element_by_id('query_ticket').click()    #时间到了先点击查询刷新一下，以防找不到元素try:


try:
    WebDriverWait(browser,10).until(EC.presence_of_element_located((By.ID, "ticket_560000K594A0")))#ticket_56000G187430高铁 K594  ticket_560000K594A0
    ticket = browser.find_element_by_xpath('//tr[@id="ticket_560000K594A0"]/td[13]/a').click() #ticket_5e000K104021
except:
    browser.find_element_by_id('query_ticket').click()
    WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.ID, "ticket_560000K594A0")))
    ticket = browser.find_element_by_xpath('//tr[@id="ticket_560000K594A0"]/td[13]/a').click()

"""normalPassenger_8 数字表示该账号下的第几位，默认从0开始如果是第一个则为normalPassenger_0"""
WebDriverWait(browser,10).until(EC.presence_of_element_located((By.ID, "normalPassenger_0")))
browser.find_element_by_id('normalPassenger_0').click()
s = Select(browser.find_element_by_id('seatType_1'))
s.select_by_value('1') #席位 O：二等座 1：硬座
browser.find_element_by_id('submitOrder_id').click()
WebDriverWait(browser,10).until(EC.presence_of_element_located((By.ID, "qr_submit_id")))
browser.find_element_by_link_text('提交订单')#browser.find_element_by_id('qr_submit_id').click()

browser.find_element_by_id('submitOrder_id').click()
